
export const BOARD_SIZE = 8;
export const INITIAL_ROWS = 3;
