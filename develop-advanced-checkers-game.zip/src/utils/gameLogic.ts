
import { Board, Player, Position, Move } from '../types';
import { BOARD_SIZE, INITIAL_ROWS } from '../constants';

export const createInitialBoard = (): Board => {
  const board: Board = Array(BOARD_SIZE).fill(null).map(() => Array(BOARD_SIZE).fill(null));

  for (let row = 0; row < BOARD_SIZE; row++) {
    for (let col = 0; col < BOARD_SIZE; col++) {
      if ((row + col) % 2 !== 0) {
        if (row < INITIAL_ROWS) {
          board[row][col] = { id: `black-${row}-${col}`, player: 'BLACK', type: 'PAWN' };
        } else if (row >= BOARD_SIZE - INITIAL_ROWS) {
          board[row][col] = { id: `red-${row}-${col}`, player: 'RED', type: 'PAWN' };
        }
      }
    }
  }
  return board;
};

export const isWithinBounds = (row: number, col: number): boolean => {
  return row >= 0 && row < BOARD_SIZE && col >= 0 && col < BOARD_SIZE;
};

export const getValidMoves = (board: Board, pos: Position, mustJump: boolean = false): Move[] => {
  const piece = board[pos.row][pos.col];
  if (!piece) return [];

  const moves: Move[] = [];
  const directions = piece.type === 'KING' 
    ? [[1, 1], [1, -1], [-1, 1], [-1, -1]] 
    : (piece.player === 'BLACK' ? [[1, 1], [1, -1]] : [[-1, 1], [-1, -1]]);

  // Check jumps first
  for (const [dr, dc] of directions) {
    const jumpRow = pos.row + dr * 2;
    const jumpCol = pos.col + dc * 2;
    const midRow = pos.row + dr;
    const midCol = pos.col + dc;

    if (isWithinBounds(jumpRow, jumpCol)) {
      const midPiece = board[midRow][midCol];
      const targetSquare = board[jumpRow][jumpCol];
      
      if (midPiece && midPiece.player !== piece.player && !targetSquare) {
        moves.push({
          from: pos,
          to: { row: jumpRow, col: jumpCol },
          captured: { row: midRow, col: midCol }
        });
      }
    }
  }

  // If there's a jump available, only jumps are valid (standard checkers rule)
  // However, this function might be called in a context where we only want to know if *this* piece can jump.
  if (moves.length > 0) return moves;
  if (mustJump) return [];

  // Check regular moves
  for (const [dr, dc] of directions) {
    const nextRow = pos.row + dr;
    const nextCol = pos.col + dc;

    if (isWithinBounds(nextRow, nextCol) && !board[nextRow][nextCol]) {
      moves.push({
        from: pos,
        to: { row: nextRow, col: nextCol }
      });
    }
  }

  return moves;
};

export const getAllValidMoves = (board: Board, player: Player): Move[] => {
  let jumpMoves: Move[] = [];
  let regularMoves: Move[] = [];

  for (let row = 0; row < BOARD_SIZE; row++) {
    for (let col = 0; col < BOARD_SIZE; col++) {
      const piece = board[row][col];
      if (piece && piece.player === player) {
        const moves = getValidMoves(board, { row, col });
        moves.forEach(move => {
          if (move.captured) jumpMoves.push(move);
          else regularMoves.push(move);
        });
      }
    }
  }

  return jumpMoves.length > 0 ? jumpMoves : regularMoves;
};

export const canJumpAgain = (board: Board, pos: Position): boolean => {
  const moves = getValidMoves(board, pos, true);
  return moves.some(m => m.captured !== undefined);
};
