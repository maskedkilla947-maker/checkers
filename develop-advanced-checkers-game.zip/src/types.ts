
export type Player = 'RED' | 'BLACK';

export type PieceType = 'PAWN' | 'KING';

export interface Piece {
  id: string;
  player: Player;
  type: PieceType;
}

export type Board = (Piece | null)[][];

export interface Position {
  row: number;
  col: number;
}

export interface Move {
  from: Position;
  to: Position;
  captured?: Position;
}
