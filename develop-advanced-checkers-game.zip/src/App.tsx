
import React, { useState, useEffect } from 'react';
import { Board, Position, Move, Player } from './types';
import { createInitialBoard, getAllValidMoves, getValidMoves, canJumpAgain } from './utils/gameLogic';
import Square from './components/Square';
import Piece from './components/Piece';
import { BOARD_SIZE } from './constants';
import { motion, AnimatePresence } from 'framer-motion';
import { RotateCcw, Trophy } from 'lucide-react';
import confetti from 'canvas-confetti';

const App: React.FC = () => {
  const [board, setBoard] = useState<Board>(createInitialBoard());
  const [currentPlayer, setCurrentPlayer] = useState<Player>('RED');
  const [selectedPos, setSelectedPos] = useState<Position | null>(null);
  const [validMoves, setValidMoves] = useState<Move[]>([]);
  const [mustContinueJump, setMustContinueJump] = useState<Position | null>(null);
  const [winner, setWinner] = useState<Player | 'DRAW' | null>(null);
  const [scores, setScores] = useState({ RED: 0, BLACK: 0 });
  const [lastMove, setLastMove] = useState<Move | null>(null);
  const [jumpWarning, setJumpWarning] = useState(false);

  // Update possible moves for the current state
  useEffect(() => {
    if (winner) return;
    
    const allMoves = getAllValidMoves(board, currentPlayer);
    if (allMoves.length === 0) {
      setWinner(currentPlayer === 'RED' ? 'BLACK' : 'RED');
    }
    
    const hasJump = allMoves.some(m => m.captured);
    setJumpWarning(hasJump);
  }, [board, currentPlayer, winner]);

  useEffect(() => {
    if (winner && winner !== 'DRAW') {
      confetti({
        particleCount: 150,
        spread: 70,
        origin: { y: 0.6 },
        colors: winner === 'RED' ? ['#dc2626', '#991b1b'] : ['#27272a', '#09090b']
      });
    }
  }, [winner]);

  const handleSquareClick = (row: number, col: number) => {
    if (winner) return;

    const clickedPos = { row, col };
    const piece = board[row][col];

    // If a move is being executed (multi-jump), only the jump piece can be selected
    if (mustContinueJump) {
      const move = validMoves.find(m => m.to.row === row && m.to.col === col);
      if (move) {
        executeMove(move);
      }
      return;
    }

    // Selecting a piece
    if (piece && piece.player === currentPlayer) {
      // Check if any pieces have a mandatory jump
      const allMoves = getAllValidMoves(board, currentPlayer);
      const pieceMoves = getValidMoves(board, clickedPos);
      
      const hasJumpAvailable = allMoves.some(m => m.captured);
      const filteredMoves = hasJumpAvailable 
        ? pieceMoves.filter(m => m.captured)
        : pieceMoves;

      if (filteredMoves.length > 0) {
        setSelectedPos(clickedPos);
        setValidMoves(filteredMoves);
      } else {
        setSelectedPos(null);
        setValidMoves([]);
      }
      return;
    }

    // Executing a move
    const move = validMoves.find(m => m.to.row === row && m.to.col === col);
    if (move) {
      executeMove(move);
    } else {
      setSelectedPos(null);
      setValidMoves([]);
    }
  };

  const executeMove = (move: Move) => {
    const newBoard = board.map(row => [...row]);
    const piece = newBoard[move.from.row][move.from.col]!;
    
    // Move piece
    newBoard[move.to.row][move.to.col] = piece;
    newBoard[move.from.row][move.from.col] = null;

    // Capture piece
    if (move.captured) {
      newBoard[move.captured.row][move.captured.col] = null;
      setScores(s => ({ ...s, [currentPlayer]: s[currentPlayer] + 1 }));
    }

    // Promotion
    let wasPromoted = false;
    if (piece.type === 'PAWN') {
      if (piece.player === 'RED' && move.to.row === 0) {
        piece.type = 'KING';
        wasPromoted = true;
      } else if (piece.player === 'BLACK' && move.to.row === BOARD_SIZE - 1) {
        piece.type = 'KING';
        wasPromoted = true;
      }
    }

    // Multi-jump check
    setLastMove(move);
    if (!wasPromoted && move.captured && canJumpAgain(newBoard, move.to)) {
      setBoard(newBoard);
      setSelectedPos(move.to);
      setMustContinueJump(move.to);
      setValidMoves(getValidMoves(newBoard, move.to, true));
    } else {
      setBoard(newBoard);
      setSelectedPos(null);
      setMustContinueJump(null);
      setValidMoves([]);
      setCurrentPlayer(currentPlayer === 'RED' ? 'BLACK' : 'RED');
    }
  };

  const resetGame = () => {
    setBoard(createInitialBoard());
    setCurrentPlayer('RED');
    setSelectedPos(null);
    setValidMoves([]);
    setMustContinueJump(null);
    setWinner(null);
    setScores({ RED: 0, BLACK: 0 });
    setLastMove(null);
  };

  return (
    <div className="min-h-screen bg-zinc-900 text-zinc-100 flex flex-col items-center justify-center p-4 font-sans">
      <div className="max-w-4xl w-full flex flex-col md:flex-row gap-8 items-center">
        
        {/* Game Info */}
        <div className="flex flex-col gap-6 w-full md:w-64">
          <div className="bg-zinc-800 p-6 rounded-2xl shadow-xl border border-zinc-700">
            <h1 className="text-3xl font-bold mb-2 text-center bg-gradient-to-r from-red-500 to-amber-500 bg-clip-text text-transparent">
              Checkers
            </h1>
            <p className="text-center text-xs text-zinc-500 mb-6 font-medium tracking-widest uppercase">Traditional Rules</p>
            
            <div className="space-y-4">
              <div className={`flex items-center justify-between p-3 rounded-xl transition-all ${currentPlayer === 'RED' ? 'bg-red-900/40 ring-2 ring-red-500' : 'bg-zinc-700/30'}`}>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-red-600" />
                  <span className="font-semibold">Red Team</span>
                </div>
                <span className="text-xl font-bold">{scores.RED}</span>
              </div>

              <div className={`flex items-center justify-between p-3 rounded-xl transition-all ${currentPlayer === 'BLACK' ? 'bg-zinc-700 ring-2 ring-zinc-400' : 'bg-zinc-700/30'}`}>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded-full bg-zinc-950 border border-zinc-700" />
                  <span className="font-semibold">Black Team</span>
                </div>
                <span className="text-xl font-bold">{scores.BLACK}</span>
              </div>
            </div>

            <AnimatePresence>
              {jumpWarning && !winner && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="mt-4 p-2 bg-amber-500/20 border border-amber-500/50 rounded-lg text-amber-500 text-xs text-center font-bold uppercase tracking-tight"
                >
                  Capture Required!
                </motion.div>
              )}
            </AnimatePresence>

            <button
              onClick={resetGame}
              className="mt-8 w-full flex items-center justify-center gap-2 py-3 px-4 bg-zinc-700 hover:bg-zinc-600 rounded-xl transition-colors font-semibold"
            >
              <RotateCcw size={20} />
              Reset Game
            </button>
          </div>

          <div className="bg-zinc-800/50 p-4 rounded-xl border border-zinc-700 text-sm text-zinc-400">
            <h3 className="font-semibold text-zinc-200 mb-2 uppercase text-xs tracking-wider">Rules</h3>
            <ul className="list-disc list-inside space-y-1">
              <li>Jump is mandatory</li>
              <li>Multi-jumps are allowed</li>
              <li>Kings can move backwards</li>
            </ul>
          </div>
        </div>

        {/* Board */}
        <div className="relative">
          <div className="bg-amber-950 p-2 md:p-4 rounded-lg shadow-2xl border-8 border-amber-900">
            <div 
              className="grid grid-cols-8 gap-0 border-2 border-amber-950"
              style={{ width: 'fit-content' }}
            >
              {board.map((row, rowIndex) => 
                row.map((piece, colIndex) => {
                  const isDark = (rowIndex + colIndex) % 2 !== 0;
                  const isValidMove = validMoves.some(m => m.to.row === rowIndex && m.to.col === colIndex);
                  const isSelected = selectedPos?.row === rowIndex && selectedPos?.col === colIndex;
                  const canClickPiece = !winner && piece?.player === currentPlayer && (!mustContinueJump || (mustContinueJump.row === rowIndex && mustContinueJump.col === colIndex));
                  const isLastMove = lastMove && (
                    (lastMove.from.row === rowIndex && lastMove.from.col === colIndex) ||
                    (lastMove.to.row === rowIndex && lastMove.to.col === colIndex)
                  );

                  return (
                    <Square
                      key={`${rowIndex}-${colIndex}`}
                      isDark={isDark}
                      isValidMove={isValidMove}
                      onClick={() => handleSquareClick(rowIndex, colIndex)}
                    >
                      {isLastMove && (
                        <div className="absolute inset-0 bg-blue-500/10 pointer-events-none" />
                      )}
                      <AnimatePresence mode="popLayout">
                        {piece && (
                          <motion.div
                            key={piece.id}
                            layoutId={piece.id}
                            initial={{ opacity: 0, scale: 0.5 }}
                            animate={{ opacity: 1, scale: 1 }}
                            exit={{ opacity: 0, scale: 0.5 }}
                            transition={{ 
                              type: 'spring', 
                              stiffness: 400, 
                              damping: 35,
                              layout: { duration: 0.3 }
                            }}
                            className="z-10"
                          >
                            <Piece
                              player={piece.player}
                              type={piece.type}
                              isSelected={isSelected}
                              isClickable={canClickPiece}
                              onClick={() => handleSquareClick(rowIndex, colIndex)}
                            />
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </Square>
                  );
                })
              )}
            </div>
          </div>

          {/* Winner Overlay */}
          <AnimatePresence>
            {winner && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="absolute inset-0 bg-black/60 backdrop-blur-md flex flex-col items-center justify-center rounded-lg z-10 p-6 text-center"
              >
                <Trophy size={64} className={winner === 'RED' ? 'text-red-500' : 'text-zinc-300'} />
                <h2 className="text-4xl font-bold mt-4 mb-2">
                  {winner === 'DRAW' ? "It's a Draw!" : `${winner === 'RED' ? 'Red' : 'Black'} Wins!`}
                </h2>
                <p className="text-zinc-400 mb-8 max-w-[200px]">
                  {winner === 'RED' ? 'The Red Team has dominated the board.' : 'The Black Team has claimed victory.'}
                </p>
                <button
                  onClick={resetGame}
                  className="bg-white text-black font-bold py-3 px-8 rounded-full hover:bg-zinc-200 transition-colors shadow-lg"
                >
                  Play Again
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

export default App;
