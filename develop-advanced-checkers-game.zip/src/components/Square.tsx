
import React from 'react';

interface SquareProps {
  isDark: boolean;
  isValidMove: boolean;
  onClick: () => void;
  children?: React.ReactNode;
}

const Square: React.FC<SquareProps> = ({ isDark, isValidMove, onClick, children }) => {
  return (
    <div
      onClick={onClick}
      className={`
        w-16 h-16 md:w-20 md:h-20 flex items-center justify-center relative
        ${isDark ? 'bg-amber-900' : 'bg-amber-100'}
        ${isValidMove ? 'cursor-pointer hover:bg-amber-800 transition-colors' : ''}
      `}
    >
      {isValidMove && (
        <div className="absolute inset-0 bg-yellow-400/30 flex items-center justify-center">
          <div className="w-4 h-4 rounded-full bg-yellow-400/50" />
        </div>
      )}
      {children}
      
      {/* Coordinates (optional, good for debugging/accessibility) */}
      {/* <span className="absolute top-0 left-0 text-[8px] text-white/20">{row},{col}</span> */}
    </div>
  );
};

export default Square;
