
import React from 'react';
import { motion } from 'framer-motion';
import { Crown } from 'lucide-react';
import { Player, PieceType } from '../types';

interface PieceProps {
  player: Player;
  type: PieceType;
  isSelected: boolean;
  isClickable: boolean;
  onClick: () => void;
}

const Piece: React.FC<PieceProps> = ({ player, type, isSelected, isClickable, onClick }) => {
  return (
    <motion.div
      layoutId={undefined} // We'll use layout transitions via parent
      initial={false}
      animate={{
        scale: isSelected ? 1.1 : 1,
        boxShadow: isSelected ? '0 0 15px rgba(255, 255, 255, 0.8)' : '0 4px 6px rgba(0, 0, 0, 0.3)',
      }}
      whileHover={isClickable ? { scale: 1.05 } : {}}
      onClick={(e) => {
        if (isClickable) {
          e.stopPropagation();
          onClick();
        }
      }}
      className={`
        w-12 h-12 md:w-16 md:h-16 rounded-full flex items-center justify-center cursor-pointer
        transition-colors duration-200 relative
        ${player === 'RED' ? 'bg-red-600 border-4 border-red-800' : 'bg-zinc-800 border-4 border-zinc-950'}
        ${isSelected ? 'ring-4 ring-yellow-400' : ''}
        ${!isClickable ? 'cursor-default' : 'cursor-pointer'}
      `}
    >
      <div className={`
        w-full h-full rounded-full border-2 border-opacity-30 flex items-center justify-center
        ${player === 'RED' ? 'border-red-400' : 'border-zinc-600'}
      `}>
        {type === 'KING' && (
          <Crown className="text-yellow-400 w-6 h-6 md:w-8 md:h-8" />
        )}
      </div>
      
      {/* Visual rings for better texture */}
      <div className="absolute inset-2 border-2 border-black/10 rounded-full" />
      <div className="absolute inset-4 border-2 border-black/10 rounded-full" />
    </motion.div>
  );
};

export default Piece;
